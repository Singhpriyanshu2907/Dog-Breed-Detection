# Dog Breeds > 2025-01-04 9:38pm
https://universe.roboflow.com/priyanshu-q6w5y/dog-breeds-logqe

Provided by a Roboflow user
License: CC BY 4.0

